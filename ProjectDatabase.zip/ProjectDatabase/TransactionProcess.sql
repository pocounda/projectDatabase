CREATE TABLE StaffPosition(
	staffPositionId CHAR(5) PRIMARY KEY CHECK (staffPositionId LIKE 'SP[0-9][0-9][0-9]'),
	staffPositionName VARCHAR(25) CHECK(staffPositionName IN('Chairman','Marketing Supervisor','Finance Manager',
													'Finance Supervisor','Marketing Manager','Senior Staff',
													'Marketing Division Head','Junior Staff','Finance Division Head',
													'Cashier')),
)

--Staff
--staff id, name, position, gender, email, phone number, date of birth, and salary
CREATE TABLE Staff(
	staffId CHAR(5) PRIMARY KEY CHECK (staffId LIKE 'ST[0-9][0-9][0-9]'),
	staffName VARCHAR(25) , 
	staffPositionId CHAR(5) foreign key references StaffPosition(staffPositionId) ON UPDATE CASCADE ON DELETE CASCADE,
	staffPositionGrade NUMERIC CHECK(staffPositionGrade>=1 AND staffPositionGrade<=50),
	staffGender VARCHAR(6) CHECK(staffGender LIKE 'Male' OR staffGender LIKE 'Female'),
	staffEmail VARCHAR(25) CHECK(staffEmail  LIKE '%@%' AND staffEmail LIKE '%.com'),
	staffPhone VARCHAR(15) CHECK(LEN(staffPhone)>=8 AND LEN(staffPhone)<=14),
	staffDOB DATE CHECK (DATEDIFF(YEAR, staffDOB, GETDATE()) > 18),
	staffSalary NUMERIC
)

--watchType
--watchType id, watchTypeName
CREATE TABLE WatchType(
	watchTypeId CHAR(5) PRIMARY KEY CHECK (watchTypeId LIKE 'WT[0-9][0-9][0-9]'),
	watchTypeName VARCHAR(25)
)

--watch
--watch id, name, type, selling price, and purchase price
CREATE TABLE Watch(
	watchId CHAR(5) PRIMARY KEY CHECK (watchId LIKE 'WH[0-9][0-9][0-9]'),
	watchName VARCHAR(25) ,
	watchTypeId CHAR(5) foreign key references WatchType (watchTypeId),
	watchSellingPrice NUMERIC,
	watchPurchasePrice NUMERIC
)

--Customer
--customer id, name, phone number, address, gender, email
CREATE TABLE Customer(
	customerId CHAR(5) PRIMARY KEY CHECK (customerId LIKE 'CS[0-9][0-9][0-9]'),
	customerName VARCHAR(25) ,
	customerPhone VARCHAR(15) CHECK(LEN(customerPhone)>=8 AND LEN(customerPhone)<=14),
	customerAddress VARCHAR(50),
	customerGender VARCHAR(6) CHECK(customerGender LIKE 'Male' OR customerGender LIKE 'Female'),
	customerEmail VARCHAR(25) CHECK(customerEmail  LIKE '%@%' AND customerEmail LIKE '%.com')
)

--Vendor
--vendor id, name, phone, address, and email
CREATE TABLE Vendor(
	vendorId CHAR(5) PRIMARY KEY CHECK (vendorId LIKE 'VN[0-9][0-9][0-9]'),
	vendorName VARCHAR(25) ,
	phoneNumber VARCHAR(15) CHECK(LEN(phoneNumber)>=8 AND LEN(phoneNumber)<=14),
	vendorAddress VARCHAR(50),
	vendorEmail VARCHAR(25) CHECK(vendorEmail  LIKE '%@%' AND vendorEmail LIKE '%.com')
)

--sales transaction header
--staff, customer, transaction date, watch sold, and the quantity of each watch sold.
CREATE TABLE SalesHeader(
	SalesId CHAR(5) PRIMARY KEY CHECK (SalesId LIKE 'SH[0-9][0-9][0-9]'),
	--SalesDetailId CHAR(5) foreign key references SalesDetail(SalesDetailId) ON UPDATE CASCADE ON DELETE CASCADE ,
	staffId CHAR(5) foreign key references Staff(staffId) ON UPDATE CASCADE ON DELETE CASCADE ,
	TransactionDate DATE
)

--sales transaction detail
--customerId, salestransactionId
CREATE TABLE SalesDetail(
	SalesDetailId CHAR(5) PRIMARY KEY CHECK (SalesDetailId LIKE 'SD[0-9][0-9][0-9]') ,
	SalesId CHAR(5) foreign key references SalesHeader (salesId) ON UPDATE CASCADE ON DELETE CASCADE ,
	customerId CHAR (5) foreign key references Customer (customerId) ON UPDATE CASCADE ON DELETE CASCADE ,
	watchId CHAR(5)foreign key references Watch(watchId) ON UPDATE CASCADE ON DELETE CASCADE,
	quantity NUMERIC
)

--purchase transaction header
--staff, vendor, transaction date, watches purchased, and the quantity of each watch purchased
CREATE TABLE PurchaseHeader(
	PurchaseId CHAR(5) PRIMARY KEY CHECK (PurchaseId LIKE 'PH[0-9][0-9][0-9]'),
	--PurchaseDetailId CHAR(5) foreign key references PurchaseDetail(PurchaseDetailId) ON UPDATE CASCADE ON DELETE CASCADE ,
	staffId CHAR(5) foreign key references Staff(staffId) ON UPDATE CASCADE ON DELETE CASCADE ,
	TransactionDate DATE
)

--purchase Transaction detail
--customerId, VendorId
CREATE TABLE PurchaseDetail(
	PurchaseDetailId CHAR (5) PRIMARY KEY CHECK (PurchaseDetailId LIKE 'PD[0-9][0-9][0-9]'),
	PurchaseId CHAR(5) foreign key references PurchaseHeader(purchaseId) ON UPDATE CASCADE ON DELETE CASCADE ,
	vendorId CHAR (5) foreign key references Vendor(vendorId) ON UPDATE CASCADE ON DELETE CASCADE ,
	watchId CHAR(5)foreign key references Watch(WatchId) ON UPDATE CASCADE ON DELETE CASCADE,
	quantity NUMERIC 
)

-- Simulasi Penjualan ke pelanggan baru
-- Seorang pelanggan baru bernama Ricardo miller ingin membeli jam tangan model Fit n Cool, Almaz, Palicade
-- dengan kuantitas masing - masing 1 unit
-- pembelian dilayani oleh Erika Lauren pada tanggal 25 januari 2019
-- Daftarkan pelanggan dahulu, lalu buat nomor transaksi penjualan, lalu isi item apa saja yang dibeli
-- terakhir tampilkan nota penjualan
INSERT INTO Customer VALUES('CS110', 'Ricardo miller', '08137492010', 'Jl. Xpress No.12', 'Male', 'rmils@gmail.com')
INSERT INTO SalesHeader VALUES('SH017','ST001',('2019-1-25'))
INSERT INTO SalesDetail VALUES('SD029','SH017','CS110','WH005',1)
INSERT INTO SalesDetail VALUES('SD030','SH017','CS110','WH009',1)
INSERT INTO SalesDetail VALUES('SD031','SH017','CS110','WH001',1)
--menampilkan nota
SELECT WatchName, w.watchSellingPrice , quantity , 'Rp. '+ CAST(SUM(w.watchSellingPrice*quantity)AS VARCHAR) AS 'Price'
FROM Customer c JOIN SalesDetail sd ON c.customerId=sd.customerId 
				JOIN SalesHeader sh ON sh.SalesId=sd.SalesId
				JOIN Watch w ON w.watchId=sd.watchId
				JOIN Staff s ON s.staffId=sh.staffId
WHERE sh.SalesId LIKE 'SH017'
GROUP BY WatchName , w.watchSellingPrice , quantity 
SELECT customerName , StaffName , 'Rp. '+ CAST(SUM(watchSellingPrice) AS VARCHAR) AS 'Grand Total'
FROM Customer c JOIN SalesDetail sd ON c.customerId=sd.customerId 
				JOIN SalesHeader sh ON sh.SalesId=sd.SalesId
				JOIN Watch w ON w.watchId=sd.watchId
				JOIN Staff s ON s.staffId=sh.staffId
WHERE sh.SalesId LIKE 'SH017'
GROUP BY customerName , StaffName

 
-- simulasi pembelian dari vendor lama
-- Denver Watch ingin memebeli jam tangan sebagai stok dari seorang vendor kenalan lama bernama Robert Heinsmann, 
-- Barang yang ingin dipesan yaitu Rennaisante , Delta dan Xenon masing masing 3 unit
-- Pembelian ditagani oleh staff bernama Evi Atma utomo pada tanggal 5 februari 2019
-- Vendor sudah terdaftar, lalu buat nomor transaksi penjualan, lalu isi item apa saja yang dibeli
INSERT INTO PurchaseHeader VALUES('PH016','ST003',('2019-2-2'))
INSERT INTO PurchaseDetail VALUES('PD027','PH016','VN100','WH002',3)
INSERT INTO PurchaseDetail VALUES('PD028','PH016','VN100','WH004',3)
INSERT INTO PurchaseDetail VALUES('PD029','PH016','VN100','WH009',3)
--menampilkan nota
SELECT WatchName, w.watchPurchasePrice , quantity , 'Rp. '+ CAST(SUM(w.watchPurchasePrice*quantity)AS VARCHAR) AS 'Price'
FROM Vendor v JOIN PurchaseDetail pd ON v.vendorId=pd.vendorId 
				JOIN PurchaseHeader ph ON ph.PurchaseId=pd.PurchaseId
				JOIN Watch w ON w.watchId=pd.watchId
				JOIN Staff s ON s.staffId=ph.staffId
WHERE ph.PurchaseId LIKE 'PH016'
GROUP BY WatchName , w.watchPurchasePrice , quantity 
SELECT VendorName , StaffName , 'Rp. '+ CAST(SUM(watchSellingPrice) AS VARCHAR) AS 'Grand Total'
FROM Vendor v JOIN PurchaseDetail pd ON v.vendorId=pd.vendorId 
				JOIN PurchaseHeader ph ON ph.PurchaseId=pd.PurchaseId
				JOIN Watch w ON w.watchId=pd.watchId
				JOIN Staff s ON s.staffId=ph.staffId
WHERE ph.PurchaseId LIKE 'PH016'
GROUP BY vendorName , StaffName