------------------------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------------------
CREATE DATABASE ProjectDatabase

USE ProjectDatabase

--staffPosition
--positionId, positionName, positionGrade
CREATE TABLE StaffPosition(
	staffPositionId CHAR(5) PRIMARY KEY CHECK (staffPositionId LIKE 'SP[0-9][0-9][0-9]'),
	staffPositionName VARCHAR(25) CHECK(staffPositionName IN('Chairman','Marketing Supervisor','Finance Manager',
													'Finance Supervisor','Marketing Manager','Senior Staff',
													'Marketing Division Head','Junior Staff','Finance Division Head',
													'Cashier')),
)

--Staff
--staff id, name, position, gender, email, phone number, date of birth, and salary
CREATE TABLE Staff(
	staffId CHAR(5) PRIMARY KEY CHECK (staffId LIKE 'ST[0-9][0-9][0-9]'),
	staffName VARCHAR(25) , 
	staffPositionId CHAR(5) foreign key references StaffPosition(staffPositionId) ON UPDATE CASCADE ON DELETE CASCADE,
	staffPositionGrade NUMERIC CHECK(staffPositionGrade>=1 AND staffPositionGrade<=50),
	staffGender VARCHAR(6) CHECK(staffGender LIKE 'Male' OR staffGender LIKE 'Female'),
	staffEmail VARCHAR(25) CHECK(staffEmail  LIKE '%@%' AND staffEmail LIKE '%.com'),
	staffPhone VARCHAR(15) CHECK(LEN(staffPhone)>=8 AND LEN(staffPhone)<=14),
	staffDOB DATE CHECK (DATEDIFF(YEAR, staffDOB, GETDATE()) > 18),
	staffSalary NUMERIC
)

--watchType
--watchType id, watchTypeName
CREATE TABLE WatchType(
	watchTypeId CHAR(5) PRIMARY KEY CHECK (watchTypeId LIKE 'WT[0-9][0-9][0-9]'),
	watchTypeName VARCHAR(25)
)

--watch
--watch id, name, type, selling price, and purchase price
CREATE TABLE Watch(
	watchId CHAR(5) PRIMARY KEY CHECK (watchId LIKE 'WH[0-9][0-9][0-9]'),
	watchName VARCHAR(25) ,
	watchTypeId CHAR(5) foreign key references WatchType (watchTypeId),
	watchSellingPrice NUMERIC,
	watchPurchasePrice NUMERIC
)

--Customer
--customer id, name, phone number, address, gender, email
CREATE TABLE Customer(
	customerId CHAR(5) PRIMARY KEY CHECK (customerId LIKE 'CS[0-9][0-9][0-9]'),
	customerName VARCHAR(25) ,
	customerPhone VARCHAR(15) CHECK(LEN(customerPhone)>=8 AND LEN(customerPhone)<=14),
	customerAddress VARCHAR(50),
	customerGender VARCHAR(6) CHECK(customerGender LIKE 'Male' OR customerGender LIKE 'Female'),
	customerEmail VARCHAR(25) CHECK(customerEmail  LIKE '%@%' AND customerEmail LIKE '%.com')
)

--Vendor
--vendor id, name, phone, address, and email
CREATE TABLE Vendor(
	vendorId CHAR(5) PRIMARY KEY CHECK (vendorId LIKE 'VN[0-9][0-9][0-9]'),
	vendorName VARCHAR(25) ,
	phoneNumber VARCHAR(15) CHECK(LEN(phoneNumber)>=8 AND LEN(phoneNumber)<=14),
	vendorAddress VARCHAR(50),
	vendorEmail VARCHAR(25) CHECK(vendorEmail  LIKE '%@%' AND vendorEmail LIKE '%.com')
)

--sales transaction header
--staff, customer, transaction date, watch sold, and the quantity of each watch sold.
CREATE TABLE SalesHeader(
	SalesId CHAR(5) PRIMARY KEY CHECK (SalesId LIKE 'SH[0-9][0-9][0-9]'),
	--SalesDetailId CHAR(5) foreign key references SalesDetail(SalesDetailId) ON UPDATE CASCADE ON DELETE CASCADE ,
	staffId CHAR(5) foreign key references Staff(staffId) ON UPDATE CASCADE ON DELETE CASCADE ,
	TransactionDate DATE
)

--sales transaction detail
--customerId, salestransactionId
CREATE TABLE SalesDetail(
	SalesDetailId CHAR(5) PRIMARY KEY CHECK (SalesDetailId LIKE 'SD[0-9][0-9][0-9]') ,
	SalesId CHAR(5) foreign key references SalesHeader (salesId) ON UPDATE CASCADE ON DELETE CASCADE ,
	customerId CHAR (5) foreign key references Customer (customerId) ON UPDATE CASCADE ON DELETE CASCADE ,
	watchId CHAR(5)foreign key references Watch(watchId) ON UPDATE CASCADE ON DELETE CASCADE,
	quantity NUMERIC
)

--purchase transaction header
--staff, vendor, transaction date, watches purchased, and the quantity of each watch purchased
CREATE TABLE PurchaseHeader(
	PurchaseId CHAR(5) PRIMARY KEY CHECK (PurchaseId LIKE 'PH[0-9][0-9][0-9]'),
	--PurchaseDetailId CHAR(5) foreign key references PurchaseDetail(PurchaseDetailId) ON UPDATE CASCADE ON DELETE CASCADE ,
	staffId CHAR(5) foreign key references Staff(staffId) ON UPDATE CASCADE ON DELETE CASCADE ,
	TransactionDate DATE
)

--purchase Transaction detail
--customerId, VendorId
CREATE TABLE PurchaseDetail(
	PurchaseDetailId CHAR (5) PRIMARY KEY CHECK (PurchaseDetailId LIKE 'PD[0-9][0-9][0-9]'),
	PurchaseId CHAR(5) foreign key references PurchaseHeader(purchaseId) ON UPDATE CASCADE ON DELETE CASCADE ,
	vendorId CHAR (5) foreign key references Vendor(vendorId) ON UPDATE CASCADE ON DELETE CASCADE ,
	watchId CHAR(5)foreign key references Watch(WatchId) ON UPDATE CASCADE ON DELETE CASCADE,
	quantity NUMERIC 
)