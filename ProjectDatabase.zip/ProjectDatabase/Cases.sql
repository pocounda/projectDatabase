--1
SELECT * FROM Staff
SELECT * FROM StaffPosition
SELECT StaffName , staffPositionName AS [StaffPosition] , CAST(COUNT(SalesId) AS VARCHAR) + ' Transaction(s)' AS 'Total Transaction'
FROM Staff s JOIN SalesHeader st ON s.staffId = st.staffId JOIN StaffPosition sp ON sp.staffPositionId = s.staffPositionId
WHERE staffPositionName LIKE '%Marketing%' AND staffPositionGrade BETWEEN 1 AND 10
GROUP BY StaffName , staffPositionName


--2
SELECT * FROM Watch
SELECT * FROM SalesDetail
SELECT sh.SalesId , TransactionDate , 'IDR' + CAST((quantity * w.watchSellingPrice) AS VARCHAR) AS [Total Price]
FROM SalesHeader sh JOIN SalesDetail sd ON sh.SalesId = sd.SalesId
	JOIN Watch w ON w.watchId = sd.watchId
WHERE sh.SalesId LIKE 'SH001' AND watchName LIKE '% % %'


--3
SELECT staffName, sh.SalesId, CONVERT(VARCHAR, TransactionDate, 107) AS [Sales Date], COUNT(DISTINCT(sd.watchId)) AS [Variance of Watch]
FROM Staff s JOIN SalesHeader sh ON s.staffId = sh.staffId
	JOIN SalesDetail sd ON sd.SalesId = sh.SalesId
WHERE quantity > 2 AND staffName LIKE '%'
GROUP BY staffName, sh.SalesId, TransactionDate


--4
SELECT * FROM Vendor
SELECT * FROM PurchaseDetail
SELECT vendorName, ph.PurchaseId, COUNT(ph.PurchaseId),CONVERT(VARCHAR, TransactionDate, 106)
FROM Vendor v JOIN PurchaseDetail pd ON v.vendorId = pd.vendorId
	JOIN PurchaseHeader ph ON ph.PurchaseId = pd.PurchaseId
		JOIN Watch w ON w.watchId = pd.watchId
GROUP BY vendorName, ph.PurchaseId, TransactionDate
HAVING SUM(watchPurchasePrice * quantity) > 15000000


--5
SELECT * FROM SalesHeader
SELECT 'Transaction no. ' + RIGHT (SalesId, 3) AS SalesId, staffName, staffPositionName
FROM SalesHeader sh JOIN Staff s ON sh.staffId = s.staffId
	JOIN StaffPosition sp ON sp.staffPositionId = s.staffPositionId
WHERE DATEPART(YEAR,staffDOB) < 1990 AND staffSalary > (SELECT AVG(staffSalary) FROM Staff)


--6
SELECT * FROM PurchaseDetail
SELECT * FROM PurchaseHeader
SELECT * FROM PurchaseHeader
WHERE DATEPART(DAY, TransactionDate) = 1
SELECT staffName, STUFF(staffPhone, 1, 1, '+12') AS [Staff Phone], CONVERT(VARCHAR, TransactionDate, 107) AS [Purchase Date]
FROM Staff s JOIN PurchaseHeader ph ON s.staffId = ph.staffId
	JOIN PurchaseDetail pd ON pd.PurchaseId = ph.PurchaseId
WHERE DATEPART(DAY, TransactionDate) = 1 AND quantity > (SELECT MIN(quantity) FROM PurchaseDetail)


--7
SELECT ph.PurchaseId, SUBSTRING(staffName, 1, CHARINDEX(' ', staffName)) AS [Staff First Name], SUM(quantity) AS [Total Quantity]
FROM Staff s JOIN PurchaseHeader ph ON s.staffId = ph.staffId
	JOIN PurchaseDetail pd ON pd.PurchaseId = ph.PurchaseId
		JOIN Watch W ON w.watchId = pd.watchId
GROUP BY ph.PurchaseId, staffName, watchPurchasePrice
HAVING SUM(quantity) BETWEEN 10 AND 30 AND watchpurchasePrice < (SELECT AVG(watchPurchasePrice) FROM Watch)


--8
SELECT * FROM Customer WHERE customerName LIKE '% % %'
SELECT * FROM SalesDetail
SELECT * FROM Watch
SELECT AVG(watchSellingPrice) FROM Watch
SELECT UPPER(customerName) AS [Customer Name], STUFF(customerPhone, 1, 1, '+62') AS [Customer Phone], 'IDR' + CAST(SUM(quantity * watchsellingPrice) AS VARCHAR) AS [Total Price]
FROM Customer c JOIN SalesDetail sd ON c.customerId = sd.customerId
	JOIN Watch w ON w.watchId = sd.watchId
WHERE customerName LIKE '% % %' AND watchsellingPrice > (SELECT AVG(watchSellingPrice) FROM Watch)
GROUP BY customerName, customerPhone


--9
SELECT * FROM Customer WHERE customerGender LIKE 'Male'
SELECT * FROM SalesDetail WHERE 1 > 2
SELECT * FROM SalesDetail
CREATE VIEW CustomerQuantityViewer AS
SELECT REPLACE(c.customerId, 'CS', 'Customer') AS CustomerId, customerName, customerEmail, MAX(quantity) AS [Maximum Quantity], MIN(quantity) AS [Minimum Quantity]
FROM Customer c JOIN SalesDetail sd ON c.customerId = sd.customerId
WHERE customerGender LIKE 'Male' AND (SELECT MIN(quantity) FROM SalesDetail) > 2
GROUP BY c.customerId, customerName, customerEmail


--10
CREATE VIEW VenderPurchaseViewer AS
SELECT  v.vendorId , UPPER(vendorName) AS [Vender Name], 'IDR' + CAST((watchPurchasePrice * quantity) AS VARCHAR) AS [Total Purchase], COUNT(DISTINCT(PurchaseId)) AS [Total Transaction]
FROM Vendor v JOIN PurchaseDetail pd ON v.vendorId = pd.vendorId
	JOIN Watch w ON w.watchId = pd.watchId
WHERE (watchPurchasePrice * quantity) > 50000000 AND (SELECT COUNT(PurchaseId) FROM PurchaseDetail) > 1
GROUP BY v.vendorId , vendorName , watchPurchasePrice, quantity
